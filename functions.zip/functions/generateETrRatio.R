generateETrRatio <- function(x) {

wthr.ETref.ETobs.Ratio= as.data.frame(t(x))
wthr.ETref.ETobs.Ratio=wthr.ETref.ETobs.Ratio[-c(1:6),]
wthr.ETref.ETobs.Ratio_num <- as.data.frame(apply(wthr.ETref.ETobs.Ratio, 2, as.numeric))
wthr.ETref.ETobs.Ratio=wthr.ETref.ETobs.Ratio_num
# colnames(wthr.ETref.ETobs.Ratio)[9:ncol(wthr.ETref.ETobs.Ratio)] = ETr_smoothFILE[9:nrow(ETr_smoothFILE),1]
# rownames(wthr.ETref.ETobs.Ratio)= colnames(ETR_normalized)
limit_inf=-0.01

for (i in (9:ncol(wthr.ETref.ETobs.Ratio))){ ## i col LC

  for (j in 1:nrow(wthr.ETref.ETobs.Ratio)) { ## j row TS

    if ((wthr.ETref.ETobs.Ratio$SR[j]) == 0) { ### during the night period, SR 0, ETr= 0
      wthr.ETref.ETobs.Ratio[j,i] = 0
    }
    if ((wthr.ETref.ETobs.Ratio$SR[j]) > 0) { ### during the day period, SR +,  ETr value should be between 0 and ETref. Otherwise, outlier
      limit_sup = wthr.ETref.ETobs.Ratio$ETref[j]
      wthr.ETref.ETobs.Ratio[j,i][wthr.ETref.ETobs.Ratio[j,i]> limit_sup]<- NA ## if the ETr is above the limit, replace by NA
      wthr.ETref.ETobs.Ratio[j,i][wthr.ETref.ETobs.Ratio[j,i]<limit_inf]<- NA ## if the ETr is negative
    }
    
  }
  
  }

for (i in (9:ncol(wthr.ETref.ETobs.Ratio))){ ## i col LC
  wthr.ETref.ETobs.Ratio[, i] <- na.approx(wthr.ETref.ETobs.Ratio[, i])
}


return(wthr.ETref.ETobs.Ratio)
}
