	calculateTr <- function(x, y, z, d) {
	  
	  
  ETr_filt_imputed_FILE <- x; pe.df.ETr <- y;
  
  LAI.mat <- z; unq.dts <- d
  
  
  ETr_smth.mat <- ETr_filt_imputed_FILE[9:nrow(ETr_filt_imputed_FILE), 
                                        9:ncol(ETr_filt_imputed_FILE)]
  
  
 
   # Calculate LAI #
  #Kar 2020 : The Leaf Area Index (LAI) was calculated from the empirical relationship that correlates the observed leaf area (LA) values with those 
  # obtained from the 3D laser scanners of the LS platform [13 : . Vadez V et al. 2015 LeasyScan: a novel concept ... )
  # y=  3DLA x= Observed LA. Relation species-dependant
  # y=0.36x +29.9             --> Observed LA(x) = (3DLA_mm²/0.36)-29.9 for pearl millet
  # y=0.36x +63.2             --> Observed LA(x) = (3DLA_mm²/0.36)-63.2  for peanut
  # y=0.39x + 302.2           --> Observed LA(x) = (3DLA_mm²/0.39)-302.2 for cowpea
  
  # * 0.26 m² to measure LAI 
################################ CALCUL LEAF AREA INDEX PER DAY    ################################ 
  for(i in 1:nrow(LAI.mat)){ ## for all unit of LAI.mat 
    
    la.df.tmp <- pe.df.ETr[pe.df.ETr$old_unit == rownames(LAI.mat)[i], ] ## select unit in common between pe.data and LAI
    
    la.df.med <- la.df.tmp %>% group_by(date) %>%  ## group by date and provide median of LeafArea3D
      dplyr::summarise(Med_LeafArea3D = median(LeafArea3D))
    
    date.mat <- data.frame(date = unq.dts, val = rep(NA, length(unq.dts))) ## create df with date, val (empty, length unique date)
    date.mat$date = ymd(date.mat$date)
    for(j in 1:nrow(date.mat)) ## for all row of this date.mat df
    {
      ifelse(date.mat$date[j] %in% la.df.med$date, ## why if else?, there is no if
             date.mat$val[j] <- la.df.med$Med_LeafArea3D[la.df.med$date == date.mat$date[j]],
             date.mat$val[j] <- NA)    ## fill in df with val= median per date
    }
  
        ### converted to  observed LA 
    sec.lai.dates <- rep(date.mat$val, each =1) ## adapté pour les intervalles 15 mins !!
    
    LAI.all.dates[i, ] <- ((((sec.lai.dates/100) - 29.9)/0.36)*(1/0.26)/10000) ##for pearl millet 
    
    ## on a des LA par m² ( 0.26 m² = taille de la lc)
    ### insert planimeter values on excel (correspond à la date du 19/10/2023)

    ### plot dataset + planimeter + save slope
    LAI = read.csv(file = "LAI_converted_with_NA_planimeter.csv", sep = ";")
    rownames(LAI)= LAI[,1]
    LAI = LAI %>% arrange(LAI$X) ##trie par ordre croissant de nom de LC
    LAI$X10.10.2023= NA
    LAI$X11.10.2023 = NA ## les données du 10 et 11 oct sont outliers dans certains cas de LC, mieux vaut les enlever pour améliorer la relation
    
    
    colnames(LAI)[9:ncol(LAI)]= sub("X","",colnames(LAI)[9:ncol(LAI)])

    
    ## removed 38:10:01 and 38:10:02 (row 854 and 855) because there are just planimeter (PE 3DLA missing data) 
    LAI= LAI[-c(854, 855),]

    ## plot data with NA (LAI = 3D LA converted +planimeter at the end)
    # data=as.data.frame(t(LAI))
    # data=data[-c(1:8),]
    # TS=rownames(data)
    # data_num <- as.data.frame(apply(data, 2, as.numeric))
    # data=data_num   
    # data$TS= TS
    # data$TS =ymd_hms(data$TS)
    # 
    # for ( i in 1: ncol(data)) {
    #   png(file = paste(opPATH.profile,i, "_LAestimed_plan_LAIobsed.png", sep = ""))
    #   plot<-
    #     ggplot(data =data, aes(x=TS))+
    #     ylab("LAI")+
    #     xlab("Timestamp")+
    #     labs(title = paste("LAI observed",colnames(data)[i]))+
    #     geom_point(aes(y = data[,i]), color = "darkred")+
    #     # ggplot2::scale_x_datetime(labels = scales::date_format(format = "%Y-%m-%d"), breaks  = "1 days")+
    #     theme(axis.text.x=element_text(angle = -45, hjust = 0))
    #   print(plot)
    #   dev.off()
    #   print(i)
    # }
    
    
    # add a day to unq.dts for planimeter data 
    unq.dts=colnames(LAI)[9:ncol(LAI)] ## there is still irrigation dates (22 days)
   length(unq.dts)
     date.mat <- data.frame(date = unq.dts, val = rep(NA, length(unq.dts))) ## create df with date, val (empty, length unique date)
    date.mat$date = dmy(date.mat$date)
    
    ### remplace NA with values with slope value
    for (i in 1:nrow(LAI)) {
      data_LC=LAI[i,9:ncol(LAI)]
      date.mat$val= t(data_LC)
      colnames(date.mat)= c("date", "val")
      if (sum(is.na(date.mat$val))!= length(date.mat$val)) {
        mod<-lm(formula =val~date, data = date.mat)
        slope=as.numeric(mod$coefficients[2])
        
        for(j in 1:length(date.mat$val)){
          if(is.na(date.mat$val[j])== TRUE){
            date.mat$val[j]= date.mat$val[j-1]+slope} else {j=j+1}
          }
        LAI[i,9:ncol(LAI)]=date.mat$val
        print(i)
      }
    }
    LC= LAI[,1]
    rownames(LAI) = LC 
    TS= colnames(LAI[9:ncol(LAI)])
    TS= dmy(TS)
    
  save(LC, file = "LC.RData")
  save(unq.dts, file = "unq.dts_for_LA_values.RData")
  save(LAI, file = "LAI_per_day.RData")# LAI per day 
  # load(file = "LAI_per_day.RData")# LAI per day 
  write.csv2(LAI, file = "LAI_observed_converted3D_plani_estim.csv")
  
  
  
  max_df=as.data.frame(colMax(LAI[,9:ncol(LAI)])) 
  max(max_df[1:nrow(max_df),]) ##  5.152123
  min_df=as.data.frame(colMin(LAI[,9:ncol(LAI)]))
  min(min_df[1:nrow(min_df),]) ##  -0.2720919
  
  ## removed negative LAI
  for (j in (9:ncol(LAI))){ 
    for (i in 1:nrow(LAI)) { 
      LAI[i,j][LAI[i,j]<0]<- NA 
    }

  }
  
   ##LAI values per day with LAI converted until 11 oct + slope value + planimeter
    data=as.data.frame(t(LAI))
    data= data[-c(1:8),]
    rownames(data)= TS
    data= cbind(TS, data)
    data_num <- as.data.frame(apply(data[,2:ncol(data)], 2, as.numeric))  # Convert all variable types to numeric
    data= cbind(data[1], data_num)
    

        for ( i in 2: ncol(data)) {
      png(file = paste(opPATH.profile,i-1, "LAI_per_day.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=data[,1]))+ ## data[,1] = TS
        ylab("Leaf area index ")+
        xlab("Timestamp")+
        labs(title = paste("Leaf area index  ",colnames(data)[i]))+
        geom_point(aes(y = data[,i]), color = "darkred")+
        scale_x_date(date_labels = "%d-%m", date_breaks = "1 day")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
        }
    
    ## update 20.03 : removed negative outliers 
    max_df=as.data.frame(colMax(LAI[,9:ncol(LAI)])) 
    max(max_df[1:nrow(max_df),]) ##  5.152123
    min_df=as.data.frame(colMin(LAI[,9:ncol(LAI)]))
    min(min_df[1:nrow(min_df),]) ## 0.000117914
    save(LAI, file = "LAI_rmd_out.RData")
    
    
    ## update 24.03 
    save(LAI, file = "LAI_per_day_update_24_03.RData")
    write.csv2(LAI, file = "LAI_per_day_update_24_03.csv")    
    
    LAI.mat
    
################################ CALCUL LEAF AREA INDEX PER INTERVAL    ################################ 
    

    val_per_interval= data.frame(matrix(NA, nrow = nrow(LAI), ncol = ncol(LAI[9:ncol(LAI)])*96)) ## on commence à 9 car debut de la meure /jour
    rownames(val_per_interval)=rownames(LAI)
    colnames(val_per_interval) = TS_seqby
    
    ## create TS with !! there are more day than usual (19 oct =planimeter)
    start_seqby= ymd_hms(paste(dmy(unq.dts[1]),as.character("00:00:00")))
    end_seqby= ymd_hms(paste(dmy(unq.dts[length(unq.dts)]),as.character("23:45:00")))
    start_seqby
    end_seqby
    
    TS_seqby= seq(start_seqby,end_seqby, by = '15 mins')
    length(TS_seqby)
    
    colnames(val_per_interval)= TS_seqby
    
    a=1
    b=96 #= seq_by*60
    
    for (i in 9:ncol(LAI)) { ## les 8 premières lignes sont des metad
      # for (i in 1:ncol(LAI.mat)) {
      sec.lai.tmp <- as.data.frame(LAI[,i])
      colnames(sec.lai.tmp) = colnames(LAI)[i]
      sec.lai.tmp = cbind(sec.lai.tmp, replicate(95,sec.lai.tmp)) #replicate the column LA per day * 96 interval of 15 min

      val_per_interval[a:b]= sec.lai.tmp
      # colnames(val_per_interval)[a:b]= colnames(sec.lai.tmp)
      a=a+96
      b=b+96
      }
    colnames(val_per_interval)=TS_seqby
    save(val_per_interval, file = 'LAI_per_15mins.RData')
    write.csv2(val_per_interval, file = "LAI_per_15mins.csv")
    
    ## update 20.03 : removed negative outliers 
    save(val_per_interval, file = "LAI_rmd_out_per_15mins.RData")
    
  ## removed irrigation dates
    load(file = "unq.dts.RData")
    # unq.dts = dmy(unq.dts)
    unq.dts_irrg_rvd= unq.dts[unq.dts !=  c("2023-09-30")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-03")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-06")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-10")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-13")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-17")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-18")]
    unq.dts_irrg_rvd= unq.dts_irrg_rvd[unq.dts_irrg_rvd !=  c("2023-10-19")] ## planimeter
    unq.dts_irrg_rvd
    
    
    i=1
    ## faire le premier jour i=1
    start_day =  ymd_hms(paste(ymd( unq.dts_irrg_rvd[i]),as.character("00:00:00")))
    start_day
    end_day = ymd_hms(paste(ymd( unq.dts_irrg_rvd[i]),as.character("23:45:00")))
    end_day
    date = as.data.frame(seq(start_day,end_day, by = '15 mins'))
    TS= date
    
    for (i in 2:length(unq.dts_irrg_rvd)) {
      start_day =  ymd_hms(paste(ymd( unq.dts_irrg_rvd[i]),as.character("00:00:00")))
      end_day = ymd_hms(paste(ymd( unq.dts_irrg_rvd[i]),as.character("23:45:00")))
      date = as.data.frame(seq(start_day,end_day, by = '15 mins'))
      TS= rbind(TS, date)
    }
    TS= TS[1:nrow(TS),]
    save(TS, file = "TS_entire_trial_rmd_irrig.RData")
    
    save(val_per_interval, file="LAI_per_15min_entire_trial.RData")

##val_per_interval contains values of LAI for all timepoints ( length(TS_seqby) = 2112), we want to keep only Timestamps TS,  length(TS)= 1344, with irrigation dates removed
    LAI.mat= val_per_interval[,as.character(TS)]
    ncol(LAI.mat)
    
    
    save(val_per_interval, file="LAI_per_15min_rmd_irrig.RData")
    
    # 
    # LC= LAI.mat[,1]
    # LAI.mat<-LAI.mat %>% arrange(LC) ##trie par ordre croissant de nom de LC 
    # LAI.mat.num <- as.data.frame(apply(LAI.mat[,2:ncol(LAI.mat)], 2, as.numeric))  # Convert all variable types to numeric
    # LAI.mat= cbind(LC,LAI.mat.num)
    # LAI.mat<-LAI.mat %>% arrange(LC) ##trie par ordre croissant de nom de LC
    # rownames(LAI.mat)=LAI.mat[,1]
    # LAI.mat=LAI.mat[,-1]
    # colnames(LAI.mat) = TS
    # LAI.mat= LAI.mat[-nrow(LAI.mat),]
    # 
    ## df LAI fini, save the file
    save(LAI.mat, file = "LAI.mat.RData")
    write.table(LAI.mat, file = "LAI.mat.csv", sep = ";", dec = ".")
    
    ## update 20.03 : removed negative outliers 
    save(LAI.mat, file = "LAI.mat_rmd_out_per_15mins.RData")
    write.table(LAI.mat, file = "LAI.mat_rmd_out.csv", sep = ";", dec = ".")
    
    
    ##### plot LAI over time to check the profile
    data=as.data.frame(t(LAI.mat))
    # colnames(data)= rownames(LAI.mat)
    # rownames(data)=TS
    TS=rownames(data)
    data$TS= TS
    data$TS =ymd_hms(data$TS)
  
    
    for ( i in 1: ncol(data)) {
      png(file = paste(opPATH.profile,i, "LAI_over_time.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=TS))+
        ylab("Leaf area index ")+
        xlab("Timestamp")+
        labs(title = paste("Leaf area index  ",colnames(data)[i]))+
        geom_point(aes(y = data[,i]), color = "darkred")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    
    
    max_df=as.data.frame(colMax(LAI.mat)) 
    max(max_df[1:nrow(max_df),]) ##  2.737671
    min_df=as.data.frame(colMin(LAI.mat))
    min(min_df[1:nrow(min_df),]) ##  -0.2331033
    LAI.mat_rmd_out= LAI.mat
   ## REMOVED OUTLIERS INF = NEGATIVE LAI
    for  (j in 1:ncol(LAI.mat_rmd_out)){ 
         for (i in 1:nrow(LAI.mat_rmd_out)) { 
           LAI.mat_rmd_out[i,j][LAI.mat_rmd_out[i,j]<0]<- NA     }
        print(j)
      }
      
    max_df=as.data.frame(colMax(LAI.mat_rmd_out)) 
    max(max_df[1:nrow(max_df),]) ##  2.737671
    min_df=as.data.frame(colMin(LAI.mat_rmd_out))
    min(min_df[1:nrow(min_df),]) ##   0.000117914 
    
    LAI.mat = LAI.mat_rmd_out

    ## updata 24.03.24
    save(LAI.mat, file = "LAI.mat_update_24_03_24.RData")
    write.csv2(LAI.mat, file = "LAI.mat_update_24_03_24.csv")
    
    
    
    save(LAI.mat, file = "LAI.mat_25_03_rmd_negative.RData,")
    write.table(LAI.mat, file = "LAI.mat_update_25_03_rmd_negative.csv", sep = ";", dec = ".")
    
    
################################ CALCUL LEAF AREA ################################ 
    # Leaf Area Index  = Leaf Area /surface de LC 
    # Leaf Area =Leaf Area Index * surface LC 
    # LA = LAI * 0.26 m²


    LEAF_AREA= data.frame(matrix(NA, nrow = nrow(LAI.mat), ncol =  ncol(LAI.mat)))
    for (i in 1:nrow(LAI.mat)){
      LEAF_AREA[i, ] <- LAI.mat[i, ]* 0.26 
      print(i)
    }
    colnames(LEAF_AREA) = TS 
    
    ## !! now all row in LC ascending order : should start with 131:07:02
    LC = rownames(LAI.mat)
    rownames(LEAF_AREA)= LC
    colnames(LEAF_AREA)=TS
    save(LEAF_AREA, file = "LEAF_AREA.RData")
    write.table(LEAF_AREA, file = "LEAF_AREA.csv", sep = ";", dec = ".")
    
    
    ## removed outliers 
    max_df=as.data.frame(colMax(LEAF_AREA)) 
    max(max_df[1:nrow(max_df),]) ## 0.7117944
    min_df=as.data.frame(colMin(LEAF_AREA))
    min(min_df[1:nrow(min_df),]) ##  3.065764e-05
    
    ## update 20.03 removed outliers 
    load( file = "LEAF_AREA_rmd_out.RData")
    save(LEAF_AREA, file = "LEAF_AREA_rmd_out.RData")
    write.table(LEAF_AREA, file = "LEAF_AREA_rmd_out.csv", sep = ";", dec = ".")
    
    
    data=as.data.frame(t(LEAF_AREA))
    colnames(data)= LC
    rownames(data)=TS
    data$TS= TS
    data$TS =ymd_hms(data$TS)
    
    for ( i in 1: ncol(data)) {
      png(file = paste(opPATH.profile,i, "LA_over_time.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=TS))+
        ylab("Leaf area (m²) ")+
        xlab("Timestamp")+
        labs(title = paste("Leaf area ",colnames(data)[i]))+
        geom_point(aes(y = data[,i]), color = "darkgreen")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
  ## update 24.03.24
    save(LEAF_AREA, file = "LEAF_AREA_update24_03_24.RData")
    write.table(LEAF_AREA, file = "LEAF_AREA_update24_03_24.csv", sep = ";", dec = ".")
    
    
############################### ETr NON NORMALIZED ############################### 
    x= ETr_filtered
    ETr_filt_imputed_FILE <- x
    ETr_smth.mat <- ETr_filt_imputed_FILE[9:nrow(ETr_filt_imputed_FILE), 
                                          9:ncol(ETr_filt_imputed_FILE)]
    
    rownames(ETr_smth.mat)=   ETr_filt_imputed_FILE[9:nrow(ETr_filt_imputed_FILE),1]
    ETr_smth.mat= cbind(rownames(ETr_smth.mat), ETr_smth.mat)
    ETr_smth.mat<-ETr_smth.mat %>% arrange(`rownames(ETr_smth.mat)`) ##trie par ordre croissant de nom de LC
    rownames(ETr_smth.mat)= ETr_smth.mat[,1]
    ETr_smth.mat= ETr_smth.mat[,-1]
    colnames(ETr_smth.mat)=TS
     
     ## add ETref values
     ETref=x[8,9:ncol(x)]
     colnames(ETref)= TS
     ETr_smth.mat = rbind(ETref,ETr_smth.mat )
     rownames(ETr_smth.mat)[1]= "ETref" 
     rownames(ETr_smth.mat)=LC
     # ETr_smth.mat=ETr_smth.mat[,-]
     
     max_df=as.data.frame(colMax(ETr_smth.mat)) 
     max(max_df[1:nrow(max_df),]) ##  0.122
     min_df=as.data.frame(colMin(ETr_smth.mat))
     min(min_df[1:nrow(min_df),]) ## -0.01
     
     
     ## removed negative values
     for (i in 1:nrow(ETr_smth.mat)){
       for (j in 1:ncol(ETr_smth.mat)){
         ETr_smth.mat[i,j][ETr_smth.mat[i,j]<0]<- NA } }
  
     
    save(ETr_smth.mat, file = "ETr_smth.mat_data_non_normalized.RData")
    write.table(ETr_smth.mat, file = "ETr_non_normalized.csv", sep = ";", dec = ".")
    

    ## update 
    load(file = "ETr_smth.mat_data_non_normalized_rmd_out.RData")
    save(ETr_smth.mat, file = "ETr_smth.mat_data_non_normalized_rmd_out.RData")
    write.table(ETr_smth.mat, file = "ETr_non_normalized.csv_rmd_out", sep = ";", dec = ".")
    
    ## update 24.03
    save(ETr_smth.mat, file = "ETr_smth.mat_update24_03_24.RData")
    write.table(ETr_smth.mat, file = "ETr_smth.mat_update24_03_24.csv", sep = ";", dec = ".")
    
    ## update 24.03
    save(ETr_smth.mat, file = "ETr_smth.mat_update24_03_24_rmd_negative.RData")
    write.table(ETr_smth.mat, file = "ETr_smth.mat_update24_03_24_rmd_negative.csv", sep = ";", dec = ".")
    
    
    save(ETr_smth.mat, file = "ETr_smth.mat_25_03_rmd_negative.RData,")
    write.table(ETr_smth.mat, file = "ETr_smth.mat_update_25_03_rmd_negative.csv", sep = ";", dec = ".")
    
    
    
    ETref= t(x[8,9:ncol(x)])
    data=as.data.frame(t(ETr_smth.mat))
    colnames(data)= LC
    data=  as.data.frame(apply(data, 2, as.numeric))
    data = cbind(ETref, data)
    colnames(data)= c("ETref",LC)
    
    data$TS= TS
    data$TS =ymd_hms(data$TS)
    
    for ( i in 2: ncol(data)) {
      png(file = paste(opPATH.profile,i-1, "_ETr_non_normalized_ETref.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=TS))+
        ylab("ETr and ETref (mm.15min-1) ")+
        xlab("Timestamp")+
        labs(title = paste("ETr filtered (non normalized) ",colnames(data)[i]))+
        geom_line(aes(y = data[,1]), color = "darkolivegreen")+
        geom_point(aes(y = data[,i]), color = "darkblue")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    

############################### ETr  NORMALIZED BY LA ############################### 
    ETr_smth.mat = ETr_smth.mat[-1,] ## enlever la premiere ligne ETref
    ## removed 38:10:01 and 38:10:02 (row 854 and 855) because there are just planimeter (PE 3DLA missing data) 
    rownames(ETr_smth.mat)[854]
    rownames(ETr_smth.mat)[855]
    
    ETr_smth.mat= ETr_smth.mat[-c(854, 855),]
    save(ETr_smth.mat, file = "ETr_smth.mat.RData")
    LC=rownames(ETr_smth.mat)
    ## length(LC) 1204 LC ok !
    
    ### normalization by LA 
    ETR_normalized= data.frame(matrix(NA, nrow = nrow(ETr_smth.mat), ncol =  ncol(ETr_smth.mat)))
    for (i in 1:nrow(ETr_smth.mat)){
      for(j in 1:ncol(ETr_smth.mat)) {
        ETR_normalized[i, j] <- ETr_smth.mat[i,j ]/ LEAF_AREA[i,j]
        ETR_normalized[i,j][ETR_normalized[i,j]<0]<- NA ## if the ETr is negative
        }
      print(i)
    }
    colnames(ETR_normalized)= TS
    rownames(ETR_normalized)= LC
    
    
    max_df=as.data.frame(colMax(ETR_normalized))
    max(max_df[1:nrow(max_df),]) ##1011.167
    min_df=as.data.frame(colMin(ETR_normalized)) ##is this maximum weight value is possible?  or outlier?
    min(min_df[1:nrow(min_df),]) ##-1438.399
    
    save(ETR_normalized, file = "ETR_normalized_data_normalized_LA.RData")
    write.table(ETR_normalized, file = "ETR_normalized_by_LA.csv", sep = ";", dec = ".")
    
    ## update 24.03
    save(ETR_normalized, file = "ETR_normalized_update24_03_24.RData")
    write.table(ETR_normalized, file = "ETR_normalized_update24_03_24.csv", sep = ";", dec = ".")
    
    
    ## removed outliers in ETr_normalized dataframe  : data should be betwwen 0 and ETref
    ## repeat the generate ETr RAtio package
    colnames(ETref)=colnames(ETR_normalized)
    ETR_normalized = rbind(ETref[1,], ETR_normalized)
    rownames(ETR_normalized)[1]="ETref"
    ETR_norm_t= as.data.frame(t(ETR_normalized))
    for (j in (2:ncol(ETR_norm_t))){ ## i col LC
      for (i in 1:nrow(ETR_norm_t)) { ## j row TS
        ETR_norm_t[i,j][ETR_norm_t[i,j]<0]<- NA ## if the ETr is negative
      }
      
    }
    
  }
    
    
    #### with NA :
    max_df=as.data.frame(colMax(ETR_normalized)) 
    max(max_df[1:nrow(max_df),]) ## 1011.167
    min_df=as.data.frame(colMin(ETR_normalized)) 
    min(min_df[1:nrow(min_df),])  ##  0

    
    save(ETR_normalized, file = "ETR_normalized_data_normalized_LA_rmd_out.RData")
    write.table(ETR_normalized, file = "ETR_normalized_by_LA_rmd_out.csv", sep = ";", dec = ".")
    
    # 
    # 
    # data=as.data.frame(t(ETR_normalized))
    # # data=as.data.frame(t(ETR_normalized))
    # data$TS= TS
    # data$TS =ymd_hms(data$TS)
    # 
    # for ( i in 1: ncol(data)) {
    #   png(file = paste(opPATH.profile,i, "_ETR_normalized.png", sep = ""))
    #   plot<-
    #     ggplot(data =data, aes(x=TS))+
    #     ylab("ETr normalized (mm.15min-1.m-2) ")+
    #     xlab("Timestamp")+
    #     labs(title = paste("ETR_normalized by LA",colnames(data)[i]))+
    #     geom_point(aes(y = data[,i]), color = "chocolate4")+
    #     ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
    #     theme(axis.text.x=element_text(angle = -45, hjust = 0))
    #   print(plot)
    #   dev.off()
    #   print(i)
    # }
    # 
   ## We observed high peak at the beginning of the experiment that does not seem logical  
    ##not always the same day : not relate to weather condition
    ## not preset for all genotypes
    ## removed these peak based on max per day 

    # 
    # data=as.data.frame(t(ETR_normalized))
    # data$TS= TS
    # data$date= date(TS)
    # data$date= as.factor(data$date)
    # 
    # ## prepare dataframe unique_date used in the loop to call date and n_day
    # unique_date= data.frame(matrix( nrow = length( unique(data$date)), ncol = 2))
    # colnames(unique_date)=c ("n_day", "day")
    # unique_date$n_day= (1:nlevels(data$date))
    # unique_date$day= levels(data$date)
    # unique_date$day= date( unique_date$day)
    # 
    # ## prepare dataframe max_dayto store value
    # max_day= data.frame(matrix(NA, nrow = length( unique(data$date)), ncol = 2)) ## create a empty dataframe to store data
    # colnames(max_day)=c ("date", "max")
    # max_day$max = as.numeric(max_day$max)
    # max_day$date = date(max_day$date)
    # 
    # dat_rmd= data.frame(matrix(NA, nrow = length(LC), ncol = 1)) ## create a empty dataframe to store data
    # rownames(dat_rmd)=LC
    # 
    # 
    # for (n in (1:(ncol(data)-2))) { # for each LC (2 last col = TS and date)
    #   print(n)
    #   subset_LC=data.frame(data$TS, data$date, data[n]) # create dataframe with only TS, date and LC n 
    #   colnames(subset_LC)= c("TS", "date", colnames(data)[n])
    #   subset_LC$date = date(subset_LC$date)
    #   
    #   for (i in 1:nrow(unique_date) ){ # for each day  
    #     
    #   subset_day<- subset_LC[subset_LC$date %in% c(unique_date[i,2]), ] ## create a dataframe with only one day
    #   max_day[i,1]= unique_date[i,2]
    #   max_day[i,2]= max(subset_day[,3])
    #   }
    #   ol <- boxplot(max_day$max, plot = FALSE)$out
    #   tf <- which(max_day$max %in% ol)
    #   date_to_rmd = max_day$date[tf]
    #   date_to_rmd
    #   data$date=date(subset_LC$date)
    #   
    #   if (length(date_to_rmd) == 0){
    #     print("all days of data have been kept")
    #     dat_rmd[n,] =0
    # 
    #   } else {
    #     for (date in 1:nrow(data)) {
    #       for (nday_to_rmd in 1:length(date_to_rmd)){
    #         if (data$date[date]  == date_to_rmd[nday_to_rmd]) {
    #           row_to_rmd=  which(data$date %in% date_to_rmd)
    #           data[row_to_rmd,n]=NA 
    #           print(paste(length(date_to_rmd),"day(s) have been removed"))
    #           dat_rmd[n,] = length(date_to_rmd)}
    #       }
    #     }
    #   }
    # }
    #   
    #   
    # ETR_normalized= as.data.frame(t(data))
    # ETR_normalized= ETR_normalized[-nrow(ETR_normalized),] # removed TS nd date 
    # ETR_normalized=  as.data.frame(apply(ETR_normalized, 2, as.numeric))
    # rownames(ETR_normalized)= LC
    # 
    # save(ETR_normalized, file = "ETR_normalized_1204LC_rmd_out.RData,")
    # 
    # 
    # 
    # for ( i in 1: ncol(data)) {
    #   png(file = paste(opPATH.profile,i, "_ETR_normalized_rmd_out.png", sep = ""))
    #   plot<-
    #     ggplot(data =data, aes(x=TS))+
    #     ylab("ETr normalized rmd out (mm.15min-1.m-2) ")+
    #     xlab("Timestamp")+
    #     labs(title = paste("ETR_normalized by LA  rmd out",colnames(data)[i]))+
    #     geom_point(aes(y = data[,i]), color = "chocolate4")+
    #     ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
    #     theme(axis.text.x=element_text(angle = -45, hjust = 0))
    #   print(plot)
    #   dev.off()
    #   print(i)
    # }
    
############################### TRANSPIRATION 1ST STEP Tr ############################### 
    Trans.mat= data.frame(matrix(NA, nrow = nrow(ETr_smth.mat), ncol =  ncol(LAI.mat))) ### ncol 96*nombre jour 14 
    rownames(Trans.mat)=LC
    colnames(Trans.mat)=TS

    for (i in 1:nrow(ETr_smth.mat)){
      if (rownames(ETr_smth.mat)[i] ==rownames(LAI.mat)[i]){
       Trans.mat[i, ] <- (1-exp(-0.463*LAI.mat[i, ]))*ETr_smth.mat[i, ] #!! why 1-(1-)
        print(i)
        }
      }
    
    colnames(Trans.mat)= TS
    rownames(Trans.mat)=LC
    
    for (j in (1:ncol(Trans.mat))){ ## i col LC
      for (i in 1:nrow(Trans.mat)) { ## j row TS
        Trans.mat[i,j][Trans.mat[i,j]<0]<- NA   }
      
    }
    
    save (Trans.mat, file = "Transpiration_Trans.mat.RData")
    write.table(Trans.mat, file = "Trans.mat.csv", sep = ";", dec = ".")
    
     
    max_df=as.data.frame(colMax(Trans.mat))
    max(max_df[1:nrow(max_df),]) #   
    min_df=as.data.frame(colMin(Trans.mat)) 
    min(min_df[1:nrow(min_df),]) #   
  
    # update 20.03 rmd outliers : 
    
    max_df=as.data.frame(colMax(Trans.mat))
    max(max_df[1:nrow(max_df),]) #   0.07207621
    min_df=as.data.frame(colMin(Trans.mat)) 
    min(min_df[1:nrow(min_df),]) # 0
    
    
    Trans.mat= Trans.mat[-ncol(Trans.mat)]
    save (Trans.mat, file = "Transpiration_Trans.mat_rmd_out.RData")
    write.table(Trans.mat, file = "Trans.mat_rmd_out.csv", sep = ";", dec = ".")
    
    # update 24.03 rmd outliers : 
    save (Trans.mat, file = "Transpiration_Trans.mat_24_03.RData")
    write.table(Trans.mat, file = "Trans.mat_24_03.csv", sep = ";", dec = ".")
    
   ## update 24.03 removed negative values 
    save (Trans.mat, file = "Transpiration_Trans.mat_24_03_rmd_negative.RData")
    write.table(Trans.mat, file = "Transpiration_Trans.mat_24_03_rmd_negative.csv", sep = ";", dec = ".")
    
    
    
    save(TR.mat, file = "Transpiration_Trans.mat_25_03_rmd_negative.RData,")
    write.table(TR.mat, file = "Transpiration_Trans.mat_update_25_03_rmd_negative.csv", sep = ";", dec = ".")
    
    
    ## add VPD 
    VPD=x[3,7:ncol(x)] # LENGTH + 1344 TS
    
    data=as.data.frame(t(Trans.mat))
    data=cbind(t(VPD), data)
    colnames(data)[1]="VPD"

    rownames(data)=TS
    data <- as.data.frame(apply(data, 2, as.numeric))
    data$TS= TS
    data$TS =ymd_hms(data$TS)
    
    
    for ( i in 2: ncol(data)) {
      png(file = paste(opPATH.profile,i-1, "_Transpiration_VPD.png", sep = ""))
      plot<-
       ggplot(data =data, aes(x=TS))+
        geom_point(aes(y = data[,1]), color = "black")+
        geom_point(aes(y = data[,i]*100), color = "aquamarine4")+
        scale_y_continuous(name="VPD (kPa)", sec.axis=sec_axis(~./100, name="Transpiration (mm.15min-1)")) +
        xlab("Timestamp")+
        labs(title = paste("Tr (LAI~ETr ) & VPD",colnames(data)[i]))+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    
    
    
    
    for ( i in 2: ncol(data)) {
      png(file = paste(opPATH.profile,i-1, "_Transpiration.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=TS))+
        geom_point(aes(y = data[,i]), color = "aquamarine4")+
        ylab("Transpiration (mm.15min-1)")+
        xlab("Timestamp")+
        labs(title = paste("Tr (LAI~ETr )",colnames(data)[i]))+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    
    
    ### plot ETr normalized and Transpiration 
    # ETR_normalized= cbind(rownames(ETR_normalized), ETR_normalized)
    # colnames(ETR_normalized)[1]="LC"
    # rownames(ETR_normalized)= paste("ETr_norm",1:nrow(ETR_normalized), sep = "")

    ETr_smth.mat= cbind(rownames(ETr_smth.mat), ETr_smth.mat)
    colnames(ETr_smth.mat)[1]="LC"
    rownames(ETr_smth.mat)= paste("ETr_",1:nrow(ETr_smth.mat), sep = "")
    
    Trans.mat= cbind(rownames(Trans.mat), Trans.mat)
    colnames(Trans.mat)[1]="LC"
    rownames(Trans.mat)= paste("Trans_",1:nrow(Trans.mat), sep = "")
    
    
    ## !! pour merger TR rate and Tr, on ne peut pas garde rles LC comme rownames. Rownames doivent être unique
    data_ETr_TR= rbind(ETr_smth.mat, Trans.mat)
    data_ETr_TR$LC =as.factor(data_ETr_TR$LC)
    
    for ( i in (levels(data_ETr_TR$LC)) ) {  ## for unq_LC = name LC 
      subset_LC<- data_ETr_TR[data_ETr_TR$LC %in% c(i), ] ## create a dataframe with data of one genotype only
      j=rownames(subset_LC)[1]
      j=sub("ETr", "",j)
      subset_LC= t(subset_LC)
      LC_name= subset_LC[1,1]
      subset_LC= subset_LC[-1,]
      subset_LC= as.data.frame(subset_LC)
      subset_LC <- as.data.frame(apply(subset_LC, 2, as.numeric))
      subset_LC$TS = ymd_hms(TS)
      colnames(subset_LC)= c("ETr", "Transp", "TS")
      
      x <- subset_LC$TS  # used to draw the plot 
      y <- subset_LC$Transp
      y2 = subset_LC$ETr
      
      
      png(file = paste(opPATH.profile,j, "_ETr_and_Transp.png", sep = ""))
      plot<-
        ggplot(data =subset_LC, aes(x))+
        ylab("ETr and Tr (mm.15min-1)")+
        xlab("Timestamp")+
        labs(title = paste("Tr (green) and ETr (brown)  ",i))+
        geom_point(aes(y = y2), color = "chocolate4")+
        geom_point(aes(y = y), color = "aquamarine4")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    

    
    ### plot ETr  and Transpiration 
    ETr_smth.mat= cbind(rownames(ETr_smth.mat), ETr_smth.mat)
    colnames(ETr_smth.mat)[1]="LC"
    rownames(ETr_smth.mat)= paste("ETr",1:nrow(ETr_smth.mat), sep = "")
    
    Trans.mat= cbind(rownames(Trans.mat), ETr_smth.mat)
    colnames(Trans.mat)[1]="LC"
    rownames(Trans.mat)= paste("Trans",1:nrow(Trans.mat), sep = "")
    
    
    ## !! pour merger TR rate and Tr, on ne peut pas garde rles LC comme rownames. Rownames doivent être unique
    data_ETr_TR= rbind(ETr_smth.mat, Trans.mat)
    data_ETr_TR$LC =as.factor(data_ETr_TR$LC)
    
    for ( i in (levels(data_ETr_TR$LC)) ) {  ## for unq_LC = name LC 
      subset_LC<- data_ETr_TR[data_ETr_TR$LC %in% c(i), ] ## create a dataframe with data of one genotype only
      j=rownames(subset_LC)[1]
      j=sub("ETr", "",j)
      subset_LC= t(subset_LC)
      LC_name= subset_LC[1,1]
      subset_LC= subset_LC[-1,]
      subset_LC= as.data.frame(subset_LC)
      subset_LC <- as.data.frame(apply(subset_LC, 2, as.numeric))
      subset_LC$TS = ymd_hms(TS)
      colnames(subset_LC)= c("ETr", "Transp", "TS")
      
      x <- subset_LC$TS  # used to draw the plot 
      y <- subset_LC$Transp
      y2 = subset_LC$ETr
      
      
      png(file = paste(opPATH.profile,j, "_ETr_and_Transp.png", sep = ""))
      plot<-
        ggplot(data =subset_LC, aes(x))+
        ylab("ETr  and Tr (mm.15min-1)")+
        xlab("Timestamp")+
        labs(title = paste("Tr (green) and ETr norm (brown)  ",i))+
        geom_point(aes(y = y), color = "aquamarine4")+
        geom_point(aes(y = y2), color = "chocolate4")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%Y-%m-%d"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    
############################### TRANSPIRATION RATE 2ND STEP  ############################### 
    rownames(Trans.mat)= Trans.mat[,1]
    Trans.mat= Trans.mat[,-1]
    
    Trans.mat <- as.data.frame(apply(Trans.mat, 2, as.numeric))
    
    
    TR.mat <- data.frame(matrix(NA, nrow = nrow(Trans.mat), ncol =  ncol(Trans.mat))) #Empty Trans Matrix
    rownames(TR.mat)= LC
    colnames(TR.mat)= TS
    
    # Calculate Transpiration Rate #
    #Kar 2020 : "The Tr values thus obtained were converted to Transpiration Rate 
    #(TR , i.e. the transpiration per unit of leaf area) by dividing Tr of each day
    #with the corresponding Observed LA (Eq.6 : TR = Tr/ ObservedLA)
    for (i in 1:nrow(TR.mat)){
      # for (j in 1:ncol(TR.mat)) {
        TR.mat[i, ] <- (Trans.mat[i, ]/ (LEAF_AREA[i, ]))
        print(i)
      }
       
    for (j in (1:ncol(TR.mat))){ ## i col LC
      for (i in 1:nrow(TR.mat)) { ## j row TS
        TR.mat[i,j][TR.mat[i,j]<0]<- NA   }
      
    }
    # # TR.mat[i, ] <- (Trans.mat[i, ]/ (sec.lai.tmp/100)) 
    # TR.mat= TR.mat[-nrow(TR.mat),]
    # TR.mat= TR.mat[-nrow(TR.mat),]
    # 
    
    save(TR.mat, file = "TR.mat_Transpiration_rate.RData")
    write.table(TR.mat, file = "TR.mat.csv", dec = ".", sep = ";")
    
    max_df=as.data.frame(colMax(TR.mat))
    max(max_df[1:nrow(max_df),]) # 32980751 !  
    min_df=as.data.frame(colMin(TR.mat)) 
    min(min_df[1:nrow(min_df),]) #  -37547.36 ! 
    
    save(TR.mat, file = "TR.mat_Transpiration_rate_rmd_out.RData")
    write.table(TR.mat, file = "TR.mat_rmd_out.csv", dec = ".", sep = ";")
    
    # update : 24/03
    save(TR.mat, file = "TR.mat_Transpiration_rate_24_03.RData")
    write.table(TR.mat, file = "TR.mat_24_03.csv", dec = ".", sep = ";")
    
    
    save(TR.mat, file = "TR.mat_Transpiration_rate_24_03_rmd_negative.RData")
    write.table(TR.mat, file = "TR.mat_24_03_rmd_negative.csv", dec = ".", sep = ";")
    
    max_df=as.data.frame(colMax(TR.mat))
    max(max_df[1:nrow(max_df),]) # 34272.99 !  
    min_df=as.data.frame(colMin(TR.mat)) 
    min(min_df[1:nrow(min_df),]) #  0
    
    # load(file = "TR.mat..removed_outliers.RData")
    data=as.data.frame(t(TR.mat))
    data=data[-nrow(data),]
    rownames(data)=TS
    data$TS= TS
    data$TS =ymd_hms(data$TS)

    for ( i in 1: ncol(data)) {
      png(file = paste(opPATH.profile,i, "_TRrate.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=TS))+
        ylab("TR rate (mm.15min-1.m-2)")+
        xlab("Timestamp")+
        labs(title = paste("Transpiration rate ",colnames(data)[i]))+
        geom_point(aes(y = data[,i]), color = "deeppink4")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    
    
    ## still high peaks to removed
    data=as.data.frame(t(TR.mat))
    data$TS= TS
    data$date= date(TS)
    data$date= as.factor(data$date)
    
    ## prepare dataframe unique_date used in the loop to call date and n_day
    unique_date= data.frame(matrix( nrow = length( unique(data$date)), ncol = 2))
    colnames(unique_date)=c ("n_day", "day")
    unique_date$n_day= (1:nlevels(data$date))
    unique_date$day= levels(data$date)
    unique_date$day= date( unique_date$day)
    
    ## prepare dataframe max_dayto store value
    max_day= data.frame(matrix(NA, nrow = length( unique(data$date)), ncol = 2)) ## create a empty dataframe to store data
    colnames(max_day)=c ("date", "max")
    max_day$max = as.numeric(max_day$max)
    max_day$date = date(max_day$date)
    
    dat_rmd= data.frame(matrix(NA, nrow = length(LC), ncol = 1)) ## create a empty dataframe to store data
    rownames(dat_rmd)=LC
    
    
    for (n in (1:(ncol(data)-2))) { # for each LC (2 last col = TS and date)
      print(n)
      subset_LC=data.frame(data$TS, data$date, data[n]) # create dataframe with only TS, date and LC n 
      colnames(subset_LC)= c("TS", "date", colnames(data)[n])
      subset_LC$date = date(subset_LC$date)
      
      for (i in 1:nrow(unique_date) ){ # for each day  
        
        subset_day<- subset_LC[subset_LC$date %in% c(unique_date[i,2]), ] ## create a dataframe with only one day
        max_day[i,1]= unique_date[i,2]
        max_day[i,2]= max(subset_day[,3])
      }
      ol <- boxplot(max_day$max, plot = FALSE)$out
      tf <- which(max_day$max %in% ol)
      date_to_rmd = max_day$date[tf]
      date_to_rmd
      data$date=date(subset_LC$date)
      
      if (length(date_to_rmd) == 0){
        print("all days of data have been kept")
        dat_rmd[n,] =0
        
      } else {
        for (date in 1:nrow(data)) {
          for (nday_to_rmd in 1:length(date_to_rmd)){
            if (data$date[date]  == date_to_rmd[nday_to_rmd]) {
              row_to_rmd=  which(data$date %in% date_to_rmd)
              data[row_to_rmd,n]=NA 
              print(paste(length(date_to_rmd),"day(s) have been removed"))
              dat_rmd[n,] = length(date_to_rmd)}
          }
        }
      }
    }
    

    
    
    for ( i in 1: ncol(data)) {
      png(file = paste(opPATH.profile,i, "_TR.mat_rmd_out.png", sep = ""))
      plot<-
        ggplot(data =data, aes(x=TS))+
        ylab("TR rate rmd out (mm.15min-1.m-2) ")+
        xlab("Timestamp")+
        labs(title = paste("ETR_normalized by LA  rmd out",colnames(data)[i]))+
        geom_point(aes(y = data[,i]), color = "chocolate4")+
        ggplot2::scale_x_datetime(labels = scales::date_format(format = "%d-%m"), breaks  = "1 days")+
        theme(axis.text.x=element_text(angle = -45, hjust = 0))
      print(plot)
      dev.off()
      print(i)
    }
    
    
    TR.mat= as.data.frame(t(data))
    TR.mat= TR.mat[-nrow(TR.mat),]
    TR.mat= TR.mat[-nrow(TR.mat),] # removed TS nd date 
    # removed TS nd date 
    TR.mat=  as.data.frame(apply(TR.mat, 2, as.numeric))
    rownames(TR.mat)= LC
    
    save(TR.mat, file = "TR.mat_update_25_03_rmd_negative.RData,")
    write.table(TR.mat, file = "TR.mat_update_25_03_rmd_negative.csv", sep = ";", dec = ".")
    
     
     Trans.mat= cbind(rownames(Trans.mat), Trans.mat)
     TR.mat= cbind(rownames(TR.mat), TR.mat)
     colnames(Trans.mat)[1]= "LC"
     colnames(TR.mat)[1]= "LC"
     rownames(Trans.mat)= paste("Tr",1:nrow(Trans.mat), sep = "")
     rownames(TR.mat)= paste("TR_rate",1:nrow(TR.mat), sep = "")
    
     ## !! pour merger TR rate and Tr, on ne peut pas garde rles LC comme rownames. Rownames doivent être unique
    data_TRrate_TR= rbind(Trans.mat, TR.mat)
     data_TRrate_TR$LC =as.factor(data_TRrate_TR$LC)
     
     for ( i in (levels(data_TRrate_TR$LC)) ) {  ## for unq_LC = name LC 
     subset_LC<- data_TRrate_TR[data_TRrate_TR$LC %in% c(i), ] ## create a dataframe with data of one genotype only
     j=rownames(subset_LC)[1]
     subset_LC= t(subset_LC)
     LC_name= subset_LC[1,1]
    subset_LC= subset_LC[-1,]
     subset_LC= as.data.frame(subset_LC)
     subset_LC <- as.data.frame(apply(subset_LC, 2, as.numeric))
     subset_LC$TS = ymd_hms(TS)
     colnames(subset_LC)= c("Transpiration", "TRrate", "TS")
     
     x <- subset_LC$TS  # used to draw the plot 
     y <- subset_LC$Transpiration
     y2 = subset_LC$TRrate
     
     
       png(file = paste(opPATH.profile,j, "_TRrate.png", sep = ""))
       plot<-
         ggplot(data =subset_LC, aes(x))+
         ylab("TRrate and Tr (mm.15min-1.m-²)")+
         xlab("Timestamp")+
         labs(title = paste("Tr (green) and TR rate (pink)  ",i))+
         geom_point(aes(y = y2), color = "deeppink4")+
         # geom_point(aes(y = y), color = "aquamarine4")+
         ggplot2::scale_x_datetime(labels = scales::date_format(format = "%Y-%m-%d"), breaks  = "1 days")+
         theme(axis.text.x=element_text(angle = -45, hjust = 0))
       print(plot)
       dev.off()
       print(i)
     }
    
    
    
    
    
    print(i)
  }
  
	
	
	
  
  
  list(Trans.mat = Trans.mat, LA3D_TS = LAI.all.dates, LAI.mat = LAI.mat, TR.mat= TR.mat)
	}
	