#' EZTr package
#'
#' Contains 16 functions including main processing pipeline
#'
#' @docType package
#'
#' @author Soumyashree Kar \email{ksoumya2301@gmail.com}
#'
#' @name EZTr
NULL
